function containerCard(clickedElement) {
  document.getElementById("cardEx").style.display = "block";

  var textTitulo = clickedElement.querySelector(".tasktext").innerText;
  var titulo = document.createElement("h1");
  titulo.className = "tituloCard";
  titulo.textContent = textTitulo;
  var local = document.getElementById("cardEx-content");
  local.appendChild(titulo);
  var corTitulo = clickedElement.querySelector(".taskCircle").background;
}

function closeContainer() {
  // Obtém o elemento da caixa de diálogo pelo ID e define o estilo de exibição como "none"
  document.getElementById("cardEx").style.display = "none";
}