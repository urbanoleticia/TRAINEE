const elements = {
    alEmailsColumn: () => document.getElementById("emailsAllowed"),
    usersColumn: () => document.getElementById("usersAccepted"),
    ulRequest: () => document.getElementById("ulUsersRequest"),
    ulUsers: () => document.getElementById("ulUsersAccepted")
}


showLoading()
firebase.auth().onAuthStateChanged(user => {
    hideLoading()
    validateWebMaster(user.uid)
})


findEmailsAllowed()
findUsers()



function findEmailsAllowed() {
    showLoading()
    firebase.firestore()
        .collection("usersAllowed")
        .get()
        .then(snapshot => {
            hideLoading()
            const emailsJSON = snapshot.docs.map(doc => ({
                ...doc.data(),
                uid: doc.id
            }))
            addEmailsToScreen(emailsJSON) 
        })
        .catch(error => {
            hideLoading()
            console.log(error)
            alert("Erro ao recuperar usuários permitidos.")
        })
}

function addEmail() {
    const emailToAdd = document.getElementById("email").value;

    // Verifique se o e-mail é válido (opcional, dependendo da sua implementação)
    if (!isValidEmail(emailToAdd)) {
        alert("Por favor, insira um e-mail válido.");
        return;
    }
      
    // Add a new document in collection "cities" with ID 'LA'
    firebase.firestore().collection('usersAllowed').add({
        email: emailToAdd
    })
    .then((docRef) => {
        console.log("E-mail adicionado com sucesso com ID: ", docRef.id);
        alert("E-mail adicionado com sucesso!");
        // Atualize a lista de e-mails permitidos após adição (se necessário)
        findEmailsAllowed();
    })
    .catch(error => {
        console.error("Erro ao adicionar e-mail:", error);
        alert("Erro ao adicionar e-mail. Por favor, tente novamente.");
    });
}

// Função para validar o formato do e-mail
function isValidEmail(email) {
    const regex = /@.*\.com/;
    return regex.test(email);
}





function addEmailsToScreen(emailsJSON) {
    elements.alEmailsColumn().innerHTML = '';  // Limpar a lista antes de adicionar os elementos

    emailsJSON.forEach(emailData => {
        const liElement = document.createElement('li');
        
        // Adicionar o e-mail ao elemento <li>
        liElement.innerText = emailData.email;

        // Adicionar botão de lixeira
        const trashIcon = document.createElement('i');
        trashIcon.className = 'fa fa-trash';  // Usando FontAwesome como exemplo para um ícone de lixeira
        trashIcon.style.cursor = 'pointer';   // Alterar o cursor para indicar que é clicável
        trashIcon.onclick = () => removeEmailFromCollection(emailData.email, emailData.uid);  // Vincular a função para remover e-mail

        // Adicionar ícone de lixeira ao elemento <li>
        liElement.appendChild(trashIcon);

        // Adicionar o elemento <li> à coluna de e-mails permitidos
        elements.alEmailsColumn().appendChild(liElement);
    });
}


function removeEmailFromCollection(email, docId) {
    if (areSure()) {
        // Referência para a coleção dentro do documento específico na coleção 'usersAllowed'
        const collectionRef = firebase.firestore()
                                        .collection("usersAllowed")
                                        .doc(docId)
                                        .collection("mwGmsXt6lCCZxCzREnaa");

        // Exclua a coleção específica
        collectionRef.doc(email).delete()
        .then(() => {
            // Atualizar a lista de e-mails permitidos após a remoção
            findEmailsAllowed();
        })
        .catch(error => {
            console.error("Erro ao remover e-mail permitido:", error);
        });
    }
}


function areSure() {
    return confirm("Tem certeza que deseja remover este e-mail?");
}



// // // // // // // // // // // // //


function validateWebMaster(uid) {
    firebase.firestore()
        .collection("users")
        .doc(uid)
        .get()
        .then(doc => {
            const user = doc.data()
            if (!isWebMaster(user)) window.location.href = "../home/home.html"
        })
        .catch(error => {
            console.log(error)
        })
}


function isWebMaster(user) { 
    if (user.adm == true) return true
    return false
}


function logout() {
    showLoading()
    firebase.auth().signOut().then(() => {
        hideLoading()
        window.location.href = "../../index.html"
    }).catch(error => {
        hideLoading()
        console.log(error)
        alert("Erro ao deslogar.")
    })
}

function voltar() {
    window.location.href = "../home/home.html";
}


function findUsers() {
    showLoading()
    firebase.firestore()
        .collection('users')
        .get()
        .then(snapshot => {
            hideLoading()
            const users = snapshot.docs.map(doc => ({
                ...doc.data(),
                uid: doc.id // Id do usuário no DB e no Auth
            }))
            addUsersToScreen(users)
        })
        .catch(error => {
            hideLoading()
            console.log(error)
            alert('Erro ao recuperar usuários.')
        })
}


function addUsersToScreen(usersJSON) {
    // usersJSON.email
    // usersJSON.adm (se tiver)

    usersJSON.forEach(user => {
        createUserCard(user)
    })
}


function areSure() {
    return confirm("Tem certeza?")
}


function createUserCard(user) {
    const liElement = document.createElement('li');
    liElement.id = user.uid


    const titleDiv = document.createElement('div');
    titleDiv.className = 'item-title';
    titleDiv.innerText = user.email

    liElement.appendChild(titleDiv);
    elements.ulUsers().appendChild(liElement)
}
