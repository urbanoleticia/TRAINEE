const columnsField = {
    ulBacklog: () => document.getElementById('ulBacklog'),
    ulDoing: () => document.getElementById('ulDoing'),
    ulReview: () => document.getElementById('ulReview'),
    ulDone: () => document.getElementById('ulDone')
}
const elements = {
    backlogBtn: () => document.getElementById('backlogNewCardBtn'),
    doingBtn: () => document.getElementById('doingNewCardBtn'),
    reviewBtn: () => document.getElementById('reviewNewCardBtn'),
    doneBtn: () => document.getElementById('doneNewCardBtn'),
}
    

function logout() {
    showLoading()
    firebase.auth().signOut().then(() => {
        hideLoading()
        window.location.href = "../../index.html"
    }).catch(error => {
        hideLoading()
        console.log(error)
        alert("Erro ao deslogar.")
    })
}


function isNewCard(card) {
    if (document.getElementById(card.uid) == null) return true
    
    return false
}


function isColumnChanged(card) {
    if (card.column != document.getElementById(card.uid).dataset.column) return true
    return false
}


function isDropColumnChanged(cardHTML) {
    console.log(cardHTML.parentNode.parentNode.id == cardHTML.dataset.column)
    if (cardHTML.dataset.column != cardHTML.parentNode.parentNode.id) return true
    return false
}


function saveDropChanges(cardHTML) {
    if (isDropColumnChanged(cardHTML)) {
        // Coluna mudou, verificar em qual linha o card esta e salvar no bd
        firebase.firestore().collection('kanban').doc(cardHTML.id).update({
            column: cardHTML.parentNode.parentNode.id
        })
        .then(() => console.log("salvei"))
        .catch(error => {
            console.log(error)
        })
        cardHTML.dataset.column = cardHTML.parentNode.parentNode.id
    }
    else {
        // Se a coluna nao mudou, verificar se a linha mudou
    }
}