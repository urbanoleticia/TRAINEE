function containerCard(textTitulo)
  {
    document.getElementById("cardEx").style.display = "block";
    var textTitulo = document.querySelector(".tasktext").innerText;
    var titulo = document.createElement("h1");
    titulo.className = "tituloCard";
    titulo.textContent = textTitulo;
    var local = document.getElementById("cardEx-content");
    local.appendChild(titulo);
    var corTitulo = document.querySelector(".taskCircle").value;
  }

  function closeContainer() {
    // Obtém o elemento da caixa de diálogo pelo ID e define o estilo de exibição como "none"
    document.getElementById("cardEx").style.display = "none";
  }

