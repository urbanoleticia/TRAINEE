(function() {
    const firebaseConfig = {
        apiKey: "AIzaSyA3HAkvBPsgn1L1UNr7HG5S2EiFXGp5GlU",
        authDomain: "focus-consultoria-kanban.firebaseapp.com",
        projectId: "focus-consultoria-kanban",
        storageBucket: "focus-consultoria-kanban.appspot.com",
        messagingSenderId: "147109750225",
        appId: "1:147109750225:web:9adf25b11ade24b2602cf0"
    };

    firebase.initializeApp(firebaseConfig)
})()