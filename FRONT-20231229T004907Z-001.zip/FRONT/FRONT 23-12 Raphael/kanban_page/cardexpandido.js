//Adicionar ouvintes para touchscreen
let touchMoved = false;

function attachTouchListeners() {
  const tasks = document.querySelectorAll('.item');
  
  tasks.forEach(task => {
    task.addEventListener('touchstart', function(event) {
      touchMoved = false; // Reinicie a variável para falso a cada novo toque
    });

    task.addEventListener('touchmove', function(event) {
      touchMoved = true; // Se o dedo se mover, defina como true
    });

    task.addEventListener('touchend', function(event) {
      if (!touchMoved) { // Se o dedo não se moveu (ou seja, foi um toque simples)
        event.preventDefault(); // Prevenindo comportamentos padrão
        containerCard(this); // Chame sua função containerCard com a tarefa clicada
      }
    }, { passive: false }); // Permitindo prevenção de comportamento padrão
  });
}


document.addEventListener('DOMContentLoaded', (event) => {
  attachTouchListeners();
});

function attachCloseListeners() {
  const closeButton = document.querySelector('#cardEx .closeButton'); // Certifique-se de ter uma classe ou ID para seu botão de fechar
  
  closeButton.addEventListener('touchstart', function(event) {
    event.preventDefault(); // Prevenindo comportamentos padrão
    closeContainer();
  }, { passive: false }); // Permitindo prevenção de comportamento padrão
}

function attachCloseListeners() {
  const closeButton = document.querySelector('#cardEx .closeButton'); // Certifique-se de ter uma classe ou ID para seu botão de fechar
  
  closeButton.addEventListener('touchstart', function(event) {
    event.preventDefault(); // Prevenindo comportamentos padrão
    closeContainer();
  }, { passive: false }); // Permitindo prevenção de comportamento padrão
}

//Continuação da função normal
function containerCard(clickedElement) {

  setTimeout(function() {
    var element = document.querySelector('.is-dragging');

    if (element) {
        // Remova a classe 'is-dragging' do elemento
        element.classList.remove('is-dragging');
    }
  }, 400);

  // Início de função para apagar a imagem fantasma do botão
  var targetNode = document.body; // ou outro elemento alvo
  var config = { childList: true }; // configuração para observar mudanças na lista de filhos

  var callback = function(mutationsList, observer) {
      for(var mutation of mutationsList) {
          if (mutation.type === 'childList') {
              // verifica se um nó filho foi adicionado
              if (mutation.addedNodes.length > 0) {
                  var lastAddedElement = mutation.addedNodes[0];
                  lastAddedElement.remove(); // remove o último elemento adicionado
                  observer.disconnect();
              }
          }
      }
  };
  var observer = new MutationObserver(callback);
  observer.observe(targetNode, config);
  // Fim de função

  document.getElementById("cardEx").style.display = "block";
  Card = clickedElement;
  var textTitulo = clickedElement.querySelector(".tasktext").innerText;
  var titulo = document.createElement("textarea");
  titulo.className = "tituloCard";
  titulo.id = "tituloCard";
  titulo.textContent = textTitulo;
  var local1 = document.getElementById("cardEx-content");
  local1.appendChild(titulo);
  //criando a box de comentario
  var boxComentario = document.createElement("textarea");
  boxComentario.className = "boxComentario";
  boxComentario.id = "boxComentario";
  var local2 = document.getElementById("descricao");
  local2.appendChild(boxComentario);
  var comentario = clickedElement.querySelector(".comentario");
  if(comentario!==null)
  {
    comentario = clickedElement.querySelector(".comentario").innerText;
    boxComentario.textContent = comentario;
  }
  else
  {
    comentario = document.createElement("div");
    comentario.className = "comentario";
    comentario.id = "comentario";
    comentario.style.display = "none";
    clickedElement.appendChild(comentario);
  }
  //criando a box de atividade
  var boxAtiv = document.createElement("textarea");
  boxAtiv.className = "boxAtividade";
  boxAtiv.id = "boxAtiv";
  var local3 = document.getElementById("atividade");
  local3.appendChild(boxAtiv);
  var ativ = clickedElement.querySelector(".atividade");
  if(ativ!==null)
  {
    ativ = clickedElement.querySelector(".atividade").innerText;
    boxAtiv.textContent = ativ;
    console.log("pres1");
  }
  else
  {
    ativ = document.createElement("div");
    ativ.className = "atividade";
    ativ.style.display = "none";
    clickedElement.appendChild(ativ);
    console.log("pres");
  }
  //criando a box de responsavel
  var boxResp = document.createElement("textarea");
  boxResp.className = "boxResponsavel";
  boxResp.id = "boxResponsavel";
  var local4 = document.getElementById("responsavel");
  local4.appendChild(boxResp);
  var responsavel = clickedElement.querySelector(".responsavel");
  if(responsavel!==null)
  {
    responsavel = clickedElement.querySelector(".responsavel").innerText;
    boxResp.textContent = responsavel;
  }
  else
  {
    responsavel = document.createElement("div");
    responsavel.className = "responsavel";
    responsavel.style.display = "none";
    clickedElement.appendChild(responsavel);
  }

  //criando input de calendario
  var inputCalendario = document.createElement("input");
  inputCalendario.className = "data";
  inputCalendario.id = "InputCalendario";
  inputCalendario.type = "date";
  var local5 = document.getElementById("data");
  local5.appendChild(inputCalendario);
  var calendario = clickedElement.querySelector(".calendario");
  if(calendario!==null)
  {
    calendario = clickedElement.querySelector(".calendario").innerText;
    console.log(calendario);
    inputCalendario.value = calendario;
  }
  else
  {
    inputCalendario.value = "aaaa-mm-dd";
    calendario = document.createElement("div");
    calendario.className = "calendario";
    calendario.id = "calendario";
    calendario.style.display = "none";
    clickedElement.appendChild(calendario);
  }

  //criando botão adm fin
  botaoAdm = document.createElement("button");
  criarBotao(botaoAdm, "Adm Fin");
  botaoMkt = document.createElement("button");
  criarBotao(botaoMkt, "Marketing");
  botaoPres = document.createElement("button");
  criarBotao(botaoPres, "Presidência");
  botaoGep = document.createElement("button");
  criarBotao(botaoGep, "GEP");
  botaoPjt = document.createElement("button");
  criarBotao(botaoPjt, "Projetos");
  botaoCom = document.createElement("button");
  criarBotao(botaoCom, "Comercial");
  corTitulo = clickedElement.querySelector(".taskCircle");
  switch(corTitulo.style.backgroundColor)
  {
    case "rgb(139, 95, 164)":
      console.log("pres");
      botaoPres.style.backgroundColor = "rgb(139, 95, 164)";
      botaoPres.value = "ativado";
      break;
    case "rgb(73, 87, 102)":
      console.log("Adm");
      botaoAdm.style.backgroundColor = "rgb(73, 87, 102)";
      botaoAdm.value = "ativado";
      break;
    case "rgb(246, 165, 45)":
      console.log("Mkt");
      botaoMkt.style.backgroundColor = "rgb(246, 165, 45)";
      botaoMkt.value = "ativado";
      break;
    case "rgb(229, 51, 36)":
      console.log("GEP");
      botaoGep.style.backgroundColor = "rgb(229, 51, 36)";
      botaoGep.value = "ativado";
      break;
    case "rgb(47, 153, 61)":
      console.log("Pjt");
      botaoPjt.style.backgroundColor = "rgb(47, 153, 61)";
      botaoPjt.value = "ativado";
      break;
    case "rgb(41, 219, 226)":
      console.log("Com");
      botaoCom.style.backgroundColor = "rgb(41, 219, 226)";
      botaoCom.value = "ativado";
      break;
  }  
}

function closeContainer() {
  var callback = function(mutationsList, observer) {
    observer.disconnect();
  };

  // Obtém o elemento da caixa de diálogo pelo ID e define o estilo de exibição como "none"
  document.getElementById("cardEx").style.display = "none";

  var titulo = document.getElementById("tituloCard").value;
  document.getElementById("tituloCard").remove();
  Card.querySelector(".tasktext").textContent = titulo;  

  var textComent = document.getElementById("boxComentario").value;
  document.getElementById("boxComentario").remove();
  var comentario = Card.querySelector(".comentario");
  comentario.textContent = textComent;

  var textAtiv = document.getElementById("boxAtiv").value;
  document.getElementById("boxAtiv").remove();
  var atividade = Card.querySelector(".atividade");
  atividade.textContent = textAtiv;

  var textResp = document.getElementById("boxResponsavel").value;
  document.getElementById("boxResponsavel").remove();
  var responsavel = Card.querySelector(".responsavel");
  responsavel.textContent = textResp;

  var data = document.getElementById("calendario").value;
  document.getElementById("InputCalendario").remove();
  Card.querySelector(".calendario").textContent = data;

  var lista = document.getElementsByClassName("setorButton");
  for(var i = lista.length - 1; i >= 0; i--)
  {
    lista[i].remove()
  }
}

function criarBotao(nomeBotao, name)
{
  var local = document.getElementById("setores");
  var espaco = document.createElement("br");
  espaco.className = "setorButton";
  local.appendChild(espaco);
  nomeBotao.className = "setorButton "+name;
  nomeBotao.setAttribute('onclick', 'mudar(this)');
  local.appendChild(nomeBotao);
  var buttonText = document.createElement("p");
  buttonText.className = "setortext";
  buttonText.textContent = name;
  nomeBotao.appendChild(buttonText);
}

function mudar(elemento) {
  switch(elemento.className)
  {
    case "setorButton Adm Fin":
      corTitulo.style.backgroundColor = "rgb(73, 87, 102)";
      botaoAdm.style.backgroundColor = "rgb(73, 87, 102)";
      botaoMkt.style.backgroundColor = "rgb(217, 217, 217)";
      botaoGep.style.backgroundColor = "rgb(217, 217, 217)";
      botaoCom.style.backgroundColor = "rgb(217, 217, 217)";
      botaoPjt.style.backgroundColor = "rgb(217, 217, 217)";
      botaoPres.style.backgroundColor = "rgb(217, 217, 217)";
    break;
    case "setorButton Marketing":
      corTitulo.style.backgroundColor = "rgb(246, 165, 45)";
      botaoMkt.style.backgroundColor = "rgb(246, 165, 45)";
      botaoAdm.style.backgroundColor = "rgb(217, 217, 217)";
      botaoGep.style.backgroundColor = "rgb(217, 217, 217)";
      botaoCom.style.backgroundColor = "rgb(217, 217, 217)";
      botaoPjt.style.backgroundColor = "rgb(217, 217, 217)";
      botaoPres.style.backgroundColor = "rgb(217, 217, 217)";
    break;
    case "setorButton GEP":
      corTitulo.style.backgroundColor = "rgb(229, 51, 36)";
      botaoAdm.style.backgroundColor = "rgb(217, 217, 217)";
      botaoMkt.style.backgroundColor = "rgb(217, 217, 217)";
      botaoGep.style.backgroundColor = "rgb(229, 51, 36)";
      botaoCom.style.backgroundColor = "rgb(217, 217, 217)";
      botaoPjt.style.backgroundColor = "rgb(217, 217, 217)";
      botaoPres.style.backgroundColor = "rgb(217, 217, 217)";
    break;
    case "setorButton Comercial":
      corTitulo.style.backgroundColor = "rgb(41, 219, 226)";
      botaoCom.style.backgroundColor = "rgb(41, 219, 226)";
      botaoAdm.style.backgroundColor = "rgb(217, 217, 217)";
      botaoMkt.style.backgroundColor = "rgb(217, 217, 217)";
      botaoGep.style.backgroundColor = "rgb(217, 217, 217)";
      botaoPjt.style.backgroundColor = "rgb(217, 217, 217)";
      botaoPres.style.backgroundColor = "rgb(217, 217, 217)";
    break;
    case "setorButton Projetos":
      corTitulo.style.backgroundColor = "rgb(47, 153, 61)";
      botaoPjt.style.backgroundColor = "rgb(47, 153, 61)";
      botaoAdm.style.backgroundColor = "rgb(217, 217, 217)";
      botaoMkt.style.backgroundColor = "rgb(217, 217, 217)";
      botaoGep.style.backgroundColor = "rgb(217, 217, 217)";
      botaoCom.style.backgroundColor = "rgb(217, 217, 217)";
      botaoPres.style.backgroundColor = "rgb(217, 217, 217)";
    break;
    case "setorButton Presidência":
      corTitulo.style.backgroundColor = "rgb(139, 95, 164)";
      botaoPres.style.backgroundColor = "rgb(139, 95, 164)";
      botaoAdm.style.backgroundColor = "rgb(217, 217, 217)";
      botaoMkt.style.backgroundColor = "rgb(217, 217, 217)";
      botaoGep.style.backgroundColor = "rgb(217, 217, 217)";
      botaoCom.style.backgroundColor = "rgb(217, 217, 217)";
      botaoPjt.style.backgroundColor = "rgb(217, 217, 217)";
    break;
  }
}