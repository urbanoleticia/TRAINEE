var imagesOff = [];
var imagesOn = [];

imagesOff[0] = "url(Images/Setores/AdmOff.png)";
imagesOff[1] = "url(Images/Setores/ComOff.png)";
imagesOff[2] = "url(Images/Setores/GepOff.png)";
imagesOff[3] = "url(Images/Setores/MktOff.png)";
imagesOff[4] = "url(Images/Setores/PjtOff.png)";
imagesOff[5] = "url(Images/Setores/PresOff.png)";
//vetor imagens on
imagesOn[0] = "url(Images/Setores/Adm.png)";
imagesOn[1] = "url(Images/Setores/Com.png)";
imagesOn[2] = "url(Images/Setores/Gep.png)";
imagesOn[3] = "url(Images/Setores/Mkt.png)";
imagesOn[4] = "url(Images/Setores/Pjt.png)";
imagesOn[5] = "url(Images/Setores/Pres.png)";

function containerCard(clickedElement) {
  document.getElementById("cardEx").style.display = "block";

  var textTitulo = clickedElement.querySelector(".tasktext").innerText;
  var titulo = document.createElement("h1");
  titulo.className = "tituloCard";
  titulo.id = "tituloCard";
  titulo.textContent = textTitulo;
  var local1 = document.getElementById("cardEx-content");
  local1.appendChild(titulo);
  var corTitulo = clickedElement.querySelector(".taskCircle").style.backgroundColor;
  switch(corTitulo)
  {
    case "rgb(139, 95, 164)":
      console.log("pres");
      break;
    case "rgb(115, 115, 115)":
      console.log("Adm");
      break;
    case "rgb(246, 165, 45)":
      console.log("Mkt");
      break;
    case "rgb(255, 49, 49)":
      console.log("GEP");
      break;
    case "rgb(47, 153, 61)":
      console.log("Pjt");
      break;
    case "rgb(0, 151, 178)":
      console.log("Com");
      break;
  }
  var boxCard = document.createElement("textarea");
  boxCard.className = "boxCard";
  boxCard.id = "boxCard";
  var local2 = document.getElementById("container");
  local2.appendChild(boxCard);
  var comentario = clickedElement.querySelector(".comentario");
  if(comentario!==null)
  {
    comentario = clickedElement.querySelector(".comentario").innerText;
    boxCard.textContent = comentario;
  }
  else
  {
    comentario = document.createElement("div");
    comentario.className = "comentario";
    comentario.id = "comentario"+textTitulo;
    comentario.style.display = "none";
    clickedElement.appendChild(comentario);
  }
}

function closeContainer() {
  // Obtém o elemento da caixa de diálogo pelo ID e define o estilo de exibição como "none"
  document.getElementById("cardEx").style.display = "none";
  var textComent = document.getElementById("boxCard").value;
  document.getElementById("boxCard").remove();
  var titulo = document.getElementById("tituloCard").innerText;
  document.getElementById("tituloCard").remove();
  var comentario = document.getElementById("comentario"+titulo);
  comentario.textContent = textComent;
}

function mudaCor(elemento, corAtual)
{
  if(elemento.value === "ativado")
  {
    switch(elemento.className)
    {
      case "admCard":
        elemento.style.backgroundImage = imagesOff[0];
      break;
      case "mktCard":
        elemento.style.backgroundImage = imagesOff[3];
      break;
      case "presCard":
        elemento.style.backgroundImage = imagesOff[5];
      break;
      case "comCard":
        elemento.style.backgroundImage = imagesOff[1];
      break;
      case "pjtCard":
        elemento.style.backgroundImage = imagesOff[4];
      break;
      case "gepCard":
        elemento.style.backgroundImage = imagesOff[2];
      break;
    }
    elemento.value = "desativado";
  }
  else
  {
    switch(elemento.className)
    {
      case "admCard":
        elemento.style.backgroundImage = imagesOn[0];
      break;
      case "mktCard":
        elemento.style.backgroundImage = imagesOn[3];
      break;
      case "presCard":
        elemento.style.backgroundImage = imagesOn[5];
      break;
      case "comCard":
        elemento.style.backgroundImage = imagesOn[1];
      break;
      case "pjtCard":
        elemento.style.backgroundImage = imagesOn[4];
      break;
      case "gepCard":
        elemento.style.backgroundImage = imagesOn[2];
      break;
    }
    elemento.value = "ativado";
  }
}

